import React from "react";
import { MainPage } from "../../assets/styled/muistyled";

const AnalyticsBoard = () => {
  return <MainPage>AnalyticsBoard</MainPage>;
};

export default AnalyticsBoard;
